const GITHUB_DESCRIPTION_FETCH = '[0] Request repository description ';
const RECEIVE_GITHUB_DESCRIPTION =
	'[1] Repository description async service returned a repository description';
const GITHUB_DESCRIPTION_FETCH_FAILED =
	'[2] Failed request getting repository description';

export default {
	GITHUB_DESCRIPTION_FETCH,
	RECEIVE_GITHUB_DESCRIPTION,
	GITHUB_DESCRIPTION_FETCH_FAILED,
};
