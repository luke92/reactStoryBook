import React from 'react';
import GitHubSearchContainer from './GitHubRepositoryDescription.container';

class GitHubSearch extends React.Component {
	render() {
		const { repositories } = this.props;
		return <GitHubSearchContainer repositories={repositories} />;
	}
}

export default GitHubSearch;
