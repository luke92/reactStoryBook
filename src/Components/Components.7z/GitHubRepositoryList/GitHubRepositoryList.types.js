const GITHUB_REPOSITORIES_FETCH =
	'[0] Request repository list order by stars desc';
const RECEIVE_GITHUB_REPOSITORIES =
	'[1] Repository list async service returned a new list';
const GITHUB_REPOSITORIES_FETCH_FAILED =
	'[2] Failed request getting repository list';

export default {
	GITHUB_REPOSITORIES_FETCH,
	RECEIVE_GITHUB_REPOSITORIES,
	GITHUB_REPOSITORIES_FETCH_FAILED,
};
